import { Routes } from '@angular/router';
import { LoginComponent } from './pages/login/login.component';
import { ContactFormComponent } from './pages/contact-form/contact-form.component';

export const routes: Routes = [
  { path: 'login', component: LoginComponent },
  {path:'contact', component: ContactFormComponent}, // Assuming ContactComponent is defined elsewhere
  { path: '', redirectTo: 'login', pathMatch: 'full' } // default redirect

];
