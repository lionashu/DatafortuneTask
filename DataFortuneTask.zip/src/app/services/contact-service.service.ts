import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ContactInfo } from '../Models/contactForm';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ContactServiceService {
  private apiUrl = '/api/registrations';

  constructor(private http: HttpClient) {}

  // POST
submitContactForm(data: ContactInfo): Observable<any> {
  return this.http.post(this.apiUrl, data);
}


  // GET
  getRegistrationById(id: string): Observable<any> {
    return this.http.get(`${this.apiUrl}/${id}`);
  }

  // DELETE
  deleteRegistrationById(id: string): Observable<any> {
    return this.http.delete(`${this.apiUrl}/${id}`);
  }
}
