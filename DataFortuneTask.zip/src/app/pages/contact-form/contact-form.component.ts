import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { ContactServiceService } from '../../services/contact-service.service';
import { CommonModule } from '@angular/common';
import { ContactFormModel, ContactInfo } from '../../Models/contactForm';

@Component({
  selector: 'app-contact-form',
   imports: [CommonModule, FormsModule, ReactiveFormsModule],
  templateUrl: './contact-form.component.html',
  styleUrls: ['./contact-form.component.css']
})
export class ContactFormComponent implements OnInit {
  model: ContactFormModel = {
  firstName: '',
  lastName: '',
  state: '',
  email: '',
  confirmEmail: '',
  subscribe: true
};

  submitted = false;
  errors: any = {};
  currentStep = 1;

  constructor(private contactService: ContactServiceService) {}

  ngOnInit(): void {}

  onSubmit() {
    this.errors = {};
    let hasError = false;

    if (!this.model.firstName) {
      this.errors.firstName = 'First Name is required';
      hasError = true;
    }
    if (!this.model.lastName) {
      this.errors.lastName = 'Last Name is required';
      hasError = true;
    }
    if (!this.model.state) {
      this.errors.state = 'State is required';
      hasError = true;
    }
    if (!this.model.email) {
      this.errors.email = 'Email is required';
      hasError = true;
    }
    if (this.model.email !== this.model.confirmEmail) {
      this.errors.confirmEmail = 'Emails do not match';
      hasError = true;
    }

    if (!hasError) {
      this.currentStep = 2;
    }
  }

onFinalSubmit() {
//   const payload = {
//     firstName: this.model.firstName,
//     lastName: this.model.lastName,
//     state: this.model.state,
//     email: this.model.email,
//     subscribe: this.model.subscribe
//   };
// console.log('Payload:', payload);
//   this.contactService.submitContactForm(payload).subscribe({
//     next: (res) => {
//       console.log('Success:', res);
      this.submitted = true;
      this.currentStep = 3;
  //   },
  //   error: (err) => {
  //     console.error('Submission failed:', err);
  //     alert('Something went wrong while submitting. Try again later.');
  //   }
  // });
}

}



