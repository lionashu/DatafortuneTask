// Models/contactForm.ts
export interface ContactInfo {
  firstName: string;
  lastName: string;
  state: string;
  email: string;
  subscribe: boolean;
}

export interface ContactFormModel extends ContactInfo {
  confirmEmail: string;
}
